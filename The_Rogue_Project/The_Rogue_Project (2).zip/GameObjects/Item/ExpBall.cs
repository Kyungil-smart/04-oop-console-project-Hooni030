﻿public class ExpBall : GameObject
{

}