﻿using System.Linq.Expressions;

public class Wall : GameObject
{


    public Wall()=> Init();
    private void Init()
    {
        Symbol = "W";
    }
}