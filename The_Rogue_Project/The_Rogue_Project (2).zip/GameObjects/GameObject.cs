﻿public abstract class GameObject
{
    public string Symbol { get; set; }
    public Vector Position { get; set; }
}