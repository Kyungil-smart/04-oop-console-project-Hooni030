﻿public class GameEndingScene : Scene
{
    public override void Enter()
    {
    }

    public override void Exit()
    {
    }

    public override void Render()
    {
    }

    public override void Update()
    {
    }
}